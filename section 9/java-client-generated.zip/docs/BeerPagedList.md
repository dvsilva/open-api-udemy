# BeerPagedList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
