# CustomerPagedList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
