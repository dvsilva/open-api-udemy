# PagedResponsePageableSort

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sorted** | **Boolean** |  |  [optional]
**unsorted** | **Boolean** |  |  [optional]
