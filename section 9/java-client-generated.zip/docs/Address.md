# Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**line1** | **String** |  |  [optional]
**city** | **String** |  |  [optional]
**stateCode** | [**StateCodeEnum**](#StateCodeEnum) | 2 Letter State Code |  [optional]
**zipCode** | **String** |  |  [optional]

<a name="StateCodeEnum"></a>
## Enum: StateCodeEnum
Name | Value
---- | -----
AL | &quot;AL&quot;
AK | &quot;AK&quot;
AZ | &quot;AZ&quot;
AR | &quot;AR&quot;
CA | &quot;CA&quot;
