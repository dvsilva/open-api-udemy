# BeerOrderLine

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**UUID**](UUID.md) |  |  [optional]
**beerId** | [**UUID**](UUID.md) |  |  [optional]
**upc** | **String** |  | 
**orderQuantity** | **Integer** |  | 
**quantityAllocated** | **Integer** |  |  [optional]
