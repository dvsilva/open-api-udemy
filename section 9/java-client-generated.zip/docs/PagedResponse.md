# PagedResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pageable** | [**PagedResponsePageable**](PagedResponsePageable.md) |  |  [optional]
**totalPages** | **Integer** |  |  [optional]
**last** | **Boolean** |  |  [optional]
**totalElements** | **Integer** |  |  [optional]
**size** | **Integer** |  |  [optional]
**number** | **Integer** |  |  [optional]
**numberOfElements** | **Integer** |  |  [optional]
**sort** | [**PagedResponsePageableSort**](PagedResponsePageableSort.md) |  |  [optional]
**first** | **Boolean** |  |  [optional]
