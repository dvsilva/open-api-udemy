# CustomerList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
