# BeerOrder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**UUID**](UUID.md) |  |  [optional]
**customerId** | [**UUID**](UUID.md) |  | 
**customerRef** | **String** |  |  [optional]
**beerOrderLines** | [**List&lt;BeerOrderLine&gt;**](BeerOrderLine.md) |  |  [optional]
**orderStatusCallbackUrl** | **String** |  |  [optional]
