# BeerList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
