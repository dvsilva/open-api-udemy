# PagedResponsePageable

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sort** | [**PagedResponsePageableSort**](PagedResponsePageableSort.md) |  |  [optional]
**offset** | **Integer** |  |  [optional]
**pageNumber** | **Integer** |  |  [optional]
**pageSize** | **Integer** |  |  [optional]
**paged** | **Boolean** |  |  [optional]
**unpaged** | **Boolean** |  |  [optional]
